from .amp_split import Train_test_split
