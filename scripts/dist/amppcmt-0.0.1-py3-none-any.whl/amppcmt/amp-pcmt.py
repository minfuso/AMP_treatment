print("Welcome to amp_pcmt package !")
